﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour {

    [SerializeField]
    private Slider soundSlider;

    // Use this for initialization
    void Start()
    {
        if (PlayerPrefs.HasKey("soundValue"))
            soundSlider.value = PlayerPrefs.GetFloat("soundValue");
    }
	
	public void OnSoundValueChange()
    {
        PlayerPrefs.SetFloat("soundValue", soundSlider.value);
    }
}
