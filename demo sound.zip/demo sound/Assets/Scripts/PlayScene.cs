﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayScene : MonoBehaviour {

    AudioSource audioSource;

	// Use this for initialization
	void Start () {
        audioSource = GetComponent<AudioSource>();

        if (PlayerPrefs.HasKey("soundValue"))
            audioSource.volume = PlayerPrefs.GetFloat("soundValue");
        else audioSource.volume = 1;
    }
	
}
